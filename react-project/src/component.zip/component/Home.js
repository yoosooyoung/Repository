import { useState } from 'react';
import { Link } from 'react-router-dom';

function Home() {
	const toList = window.localStorage.getItem('finallyList');

	var arr;
	if (toList == null) {
		arr = [];
	} else {
		arr = JSON.parse(toList);
	}
	const [parsedToDos, setParsed] = useState(arr);
	const onSubmit = (item, e) => {
		e.preventDefault();
		if (!window.confirm('삭제하시겠습니까?')) {
			alert('취소되었습니다.');
		} else {
			var newArray = parsedToDos.filter(
				(storageItem) => storageItem.key !== item.key
			);
			localStorage.removeItem('finallyList');

			if (newArray.length !== 0) {
				localStorage.setItem('finallyList', JSON.stringify(newArray));
			}
			setParsed(JSON.parse(window.localStorage.getItem('finallyList')));
		}
	};
	return (
		<div className="inner">
			<h1>List</h1>
			<ul className="li_style">
				<li>
					<div>번호</div>
					<div>제목</div>
					<div>기능</div>
				</li>
			</ul>
			<ul className="li_style">
				{parsedToDos != null ? (
					parsedToDos.map((item, index) => (
						<li key={index}>
							<div>{item.key}</div>
							<div>
								<Link to={`view/` + item.key}>{item.value}</Link>
							</div>
							<div>
								<button
									onClick={(e) => {
										onSubmit(item, e);
									}}
								>
									삭제
								</button>
							</div>
						</li>
					))
				) : (
					<li className="empty">
						<div>글이 없습니다.</div>
					</li>
				)}
			</ul>
			<form>
				<button>
					<Link to={`write`}>글쓰기</Link>
				</button>
			</form>
		</div>
	);
}
export default Home;
